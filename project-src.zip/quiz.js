﻿(async function () {
  const getLang = () => (window.i18n?.current || document.documentElement.lang || 'FR').toUpperCase();

  async function loadCodebook() {
    const res = await fetch('./data/codebook_v1.json', { cache: 'no-store' });
    if (!res.ok) throw new Error('Impossible de charger data/codebook_v1.json');
    return res.json();
  }

  function pickSix(items) {
    const arr = items.slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.slice(0, 6);
  }

  function renderQuestion(container, q, idx) {
    const row = document.createElement('div');
    row.className = 'card';
    row.innerHTML = `
      <div class="q-stem">${idx+1}. ${q.stem}</div>
      <div class="choices">
        <label>Fc :
          <select data-role="fc">
            ${[0,1,2,3,4,5].map(n=>`<option value="${n}">${n}</option>`).join('')}
          </select>
        </label>
        <label>Fi :
          <select data-role="fi">
            ${[0,1,2,3,4,5].map(n=>`<option value="${n}">${n}</option>`).join('')}
          </select>
        </label>
        <details class="hint"><summary>Conseil</summary>
          <div>
            <strong>Rappel :</strong> Fi = obstacles qui empêchent réellement le telos
            (la simple description d’un problème peut renforcer Fc).
          </div>
        </details>
      </div>
    `;
    container.appendChild(row);
    return row;
  }

  function grade(one, fc, fi) {
    const fcOk = Math.abs(fc - one.Fc_target) <= 1;
    const fiOk = Math.abs(fi - one.Fi_target) <= 1;
    return { pass: (fcOk && fiOk), fcOk, fiOk };
  }

  try {
    const lang = getLang();
    const codebook = await loadCodebook();
    const pool = codebook.filter(x => x.lang.toUpperCase() === lang);
    if (pool.length < 6) throw new Error('Codebook insuffisant pour cette langue (>=6 requis)');

    const quizItems = pickSix(pool);
    const host = document.getElementById('quiz');
    const nodes = quizItems.map((q,i)=>renderQuestion(host,q,i));

    const progress = document.getElementById('progress');
    const btn = document.getElementById('btnSubmit');
    const scoreBadge = document.getElementById('score');

    host.addEventListener('change', () => {
      const filled = nodes.filter(n => n.querySelector('select[data-role="fc"]') && n.querySelector('select[data-role="fi"]')).length;
      progress.style.width = Math.round((filled / nodes.length) * 100) + '%';
      btn.disabled = false;
    });

    btn.addEventListener('click', () => {
      let correct = 0;
      nodes.forEach((n, idx) => {
        const q = quizItems[idx];
        const fc = parseInt(n.querySelector('select[data-role="fc"]').value, 10);
        const fi = parseInt(n.querySelector('select[data-role="fi"]').value, 10);
        const g = grade(q, fc, fi);
        if (g.pass) correct += 1;
      });

      const result = window.QuizGate.submitQuizResult(correct, nodes.length);
      scoreBadge.textContent = `Score: ${Math.round(result.score*100)}% (${correct}/${nodes.length})`;

      if (result.passed) {
        alert("Bravo ! Quiz réussi. Vous pouvez annoter.");
        window.location.href = "./index.html";
      } else {
        if (window.QuizGate.isLocked()) {
          alert("Vous avez atteint 3 échecs. Réessayez plus tard.");
        } else {
          alert("Quiz non validé. Révisez et réessayez.");
        }
      }
    });

  } catch (e) {
    console.error(e);
    alert("Erreur de chargement du quiz. Vérifiez data/codebook_v1.json.");
  }
})();
