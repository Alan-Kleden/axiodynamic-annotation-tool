/* quiz_gate.js — v3.2 (modal + anti-bypass + Fc/Fi relation)
   - Modal superposé (#quiz-modal / #quiz-card) avec conteneur #quiz-container
   - Verrou avant annotation tant que le quiz n’est pas validé
   - Chargement codebook JSON (chemin paramétrable)
   - Scoring hybride : intensité ±1, structure Δ=Fc−Fi ±1, cohérence blocage (Fi min)
   - LocalStorage : quizPassed, quizScore, quizAttempts, quizVersion
*/

(function () {
  "use strict";

  // ====== Config ======
  const PATH_CODEBOOK = "data/codebook_v1.json";   // Ajustez selon votre arbo
  const LS_KEYS = {
    PASSED: "quiz_passed_v1",
    SCORE: "quiz_score_v1",
    ATTEMPTS: "quiz_attempts_v1",
    VERSION: "quiz_version_v1"
  };
  const QUIZ_VERSION    = "v3.2-modal";
  const PASS_THRESHOLD  = 0.70;
  const NUM_QUESTIONS   = 6;
  const TOL_FC_FI       = 1;  // |Fc - Fc*|, |Fi - Fi*|
  const TOL_DELTA       = 1;  // |(Fc-Fi) - (Fc*-Fi*)|
  const TH_EQ           = 2;  // |Δ| <= 2 => EQUAL
  const TH_EQ_RELAX     = 3;
  const MIN_FI_IF_BLOCK = 3;  // si blocage explicite
  const MIN = 0, MAX = 5;

  // ====== Utils ======
  const $  = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  const clamp01 = (v) => Math.max(MIN, Math.min(MAX, v|0));
  const t = (key, fallback) => {
    try {
      if (window.translations) {
        const lang = window.currentLanguage
          || $("#language-select")?.value
          || "fr";
        return window.translations[lang]?.[key]
            || window.translations["en"]?.[key]
            || fallback || key;
      }
    } catch {}
    return fallback || key;
  };
  function shuffle(a) {
    const arr = a.slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = (Math.random() * (i + 1)) | 0;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  function saveLS(k, v){ try{ localStorage.setItem(k, String(v)); }catch{} }
  function getLS(k){ try{ return localStorage.getItem(k); }catch{ return null; } }
  function clearQuizState(){
    saveLS(LS_KEYS.PASSED, "");
    saveLS(LS_KEYS.SCORE, "");
    const att = (parseInt(getLS(LS_KEYS.ATTEMPTS)||"0",10) || 0) + 1;
    saveLS(LS_KEYS.ATTEMPTS, att);
  }

  // ====== Modal ======
  function createQuizModal() {
    // Backdrop
    let modal = document.getElementById("quiz-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "quiz-modal";
      Object.assign(modal.style, {
        position: "fixed", inset: "0",
        background: "rgba(0,0,0,.45)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: "9999"
      });
      document.body.appendChild(modal);
    }
    // Card
    let card = document.getElementById("quiz-card");
    if (!card) {
      card = document.createElement("div");
      card.id = "quiz-card";
      Object.assign(card.style, {
        width: "min(920px, 92vw)", maxHeight: "88vh", overflow: "auto",
        background: "#fff", borderRadius: "12px",
        boxShadow: "0 12px 28px rgba(0,0,0,.25)",
        padding: "16px 18px"
      });
      modal.appendChild(card);
    }
    // Container
    let container = document.getElementById("quiz-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "quiz-container";
      card.appendChild(container);
    }
    // Empêche le scroll du fond
    document.documentElement.style.overflow = "hidden";
    return container;
  }
  function destroyQuizModal() {
    const modal = document.getElementById("quiz-modal");
    if (modal) modal.remove();
    document.documentElement.style.overflow = "";
  }

  // ====== État ======
  let codebook = [];
  let quizItems = [];
  let answers = [];

  // ====== Scoring ======
  function relationFromDiff(d){
    if (Math.abs(d) <= TH_EQ) return "EQUAL";
    return d > 0 ? "FC_DOM" : "FI_DOM";
  }
  function scoreOne(item, ans){
    const FcT = clamp01(Number(item.Fc_target));
    const FiT = clamp01(Number(item.Fi_target));
    const Fc  = clamp01(Number(ans.Fc));
    const Fi  = clamp01(Number(ans.Fi));

    const hasBlock = (Array.isArray(item.block_quotes) && item.block_quotes.length>0)
                  || (item.blocker_type && item.blocker_type !== "null");

    const deltaT = FcT - FiT;
    const deltaU = Fc  - Fi;

    const nearFc    = Math.abs(Fc - FcT) <= TOL_FC_FI;
    const nearFi    = Math.abs(Fi - FiT) <= TOL_FC_FI;
    const sameOrder = (FcT >= FiT) === (Fc >= Fi);
    const nearDelta = Math.abs(deltaU - deltaT) <= TOL_DELTA;
    const fiLogicOK = hasBlock ? (Fi >= MIN_FI_IF_BLOCK) : true;

    let sStruct = (sameOrder && nearDelta) ? 1 : (sameOrder || nearDelta) ? 0.6 : 0.2;
    let sIntensity = (nearFc && nearFi) ? 1 : (nearFc || nearFi) ? 0.5 : 0.2;

    let s = 0.6*sStruct + 0.4*sIntensity;
    if (!fiLogicOK) s *= 0.7;

    return Math.max(0, Math.min(1, s));
  }
  function computeScore(){
    const perItem = answers.map(a => {
      const it = quizItems.find(q => q.id === a.id);
      return { id: a.id, s: scoreOne(it, a) };
    });
    const mean = perItem.reduce((acc,x)=>acc+x.s,0) / (perItem.length || 1);
    return { perItem, mean };
  }

  // ====== UI ======
  function renderQuiz(container){
    container.innerHTML = `
      <h2>🎯 Quiz Codebook</h2>
      <p>Évaluez <strong>Fc</strong> et <strong>Fi</strong> pour chaque mini-texte.
      Rappel : si le <em>telos</em> est explicitement empêché, <strong>Fi</strong> ne peut être très bas.</p>
    `;

    const form = document.createElement("div");
    form.className = "quiz-form";
    quizItems.forEach((q, idx) => {
      const tipsPro = (q.pro_quotes || []).map(x => `<code>“${x}”</code>`).join(" ");
      const tipsBl  = (q.block_quotes || []).map(x => `<code>“${x}”</code>`).join(" ");
      const card = document.createElement("div");
      card.className = "quiz-card";
      card.dataset.qid = q.id;
      card.innerHTML = `
        <div class="q-header">
          <div class="q-num">Q${idx+1}/${quizItems.length}</div>
          <div class="q-telos"><strong>Telos :</strong> ${q.telos||""}</div>
          <div class="q-explicitness">Explicitation : ${q.explicitness||"-"}/5</div>
        </div>
        <div class="q-stem">${q.stem||""}</div>
        <details class="q-hints">
          <summary>Indices textuels</summary>
          <ul>
            <li><strong>Pro-action (Fc) :</strong> ${tipsPro || "—"}</li>
            <li><strong>Blocage (Fi) :</strong> ${tipsBl  || "—"}</li>
          </ul>
        </details>
        <div class="q-inputs">
          <label>Fc :
            <input type="range" min="0" max="5" step="1" value="0" class="inp-fc"/>
            <span class="val-fc">0</span>/5
          </label>
          <label>Fi :
            <input type="range" min="0" max="5" step="1" value="0" class="inp-fi"/>
            <span class="val-fi">0</span>/5
          </label>
        </div>
        <div class="q-feedback" aria-live="polite"></div>
      `;
      form.appendChild(card);
    });
    container.appendChild(form);

    const actions = document.createElement("div");
    actions.className = "quiz-actions";
    actions.innerHTML = `
      <button id="btn-quiz-submit" class="primary">Valider le quiz</button>
      <button id="btn-redo-quiz" class="ghost">Refaire le quiz</button>
    `;
    container.appendChild(actions);

    $$(".quiz-card .inp-fc").forEach(inp => {
      inp.addEventListener("input", e => {
        const v = clamp01(parseInt(e.target.value,10));
        e.target.value = String(v);
        e.target.closest(".quiz-card").querySelector(".val-fc").textContent = String(v);
      });
    });
    $$(".quiz-card .inp-fi").forEach(inp => {
      inp.addEventListener("input", e => {
        const v = clamp01(parseInt(e.target.value,10));
        e.target.value = String(v);
        e.target.closest(".quiz-card").querySelector(".val-fi").textContent = String(v);
      });
    });

    $("#btn-quiz-submit")?.addEventListener("click", onSubmitQuiz);
    $("#btn-redo-quiz")?.addEventListener("click", () => { clearQuizState(); showQuizGate(true); });
  }

  function onSubmitQuiz(){
    answers = $$(".quiz-card").map(card => {
      const id = card.dataset.qid;
      const Fc = clamp01(parseInt(card.querySelector(".inp-fc")?.value || "0",10));
      const Fi = clamp01(parseInt(card.querySelector(".inp-fi")?.value || "0",10));
      return { id, Fc, Fi, card };
    });

    const { perItem, mean } = computeScore();

    perItem.forEach(({ id, s }) => {
      const a  = answers.find(x => x.id===id);
      const it = quizItems.find(x => x.id===id);
      const fb = a.card.querySelector(".q-feedback");
      const ok = s >= 0.7;
      fb.innerHTML = `
        ${ok ? "✅" : "⚠️"} Score item : ${(s*100).toFixed(0)}%
        <ul class="mini">
          <li>Vous : Fc=${a.Fc}, Fi=${a.Fi}</li>
          <li>Attendu : Fc=${it.Fc_target}, Fi=${it.Fi_target}</li>
          <li>Δ (Fc−Fi) : vous ${a.Fc - a.Fi}, attendu ${it.Fc_target - it.Fi_target}</li>
        </ul>
      `;
      fb.classList.toggle("ok", ok);
      fb.classList.toggle("ko", !ok);
    });

    const passed = mean >= PASS_THRESHOLD;
    saveLS(LS_KEYS.SCORE, mean.toFixed(4));
    saveLS(LS_KEYS.PASSED, passed ? "true" : "false");
    saveLS(LS_KEYS.VERSION, QUIZ_VERSION);

    const container = $("#quiz-container");
    const panel = document.createElement("div");
    panel.className = "quiz-result";
    panel.innerHTML = `
      <hr/>
      <p><strong>Score global :</strong> ${(mean*100).toFixed(0)}% — ${passed ? "✅ Réussi" : "❌ À reprendre"}</p>
      <div class="quiz-actions">
        ${passed ? `<button id="btn-go-annot" class="primary">Commencer l’annotation</button>` : ""}
        <button id="btn-redo" class="ghost">Refaire le quiz</button>
      </div>
    `;
    container.appendChild(panel);

    $("#btn-go-annot")?.addEventListener("click", () => { destroyQuizModal(); showAnnotation(); });
    $("#btn-redo")?.addEventListener("click", () => { clearQuizState(); showQuizGate(true); });
  }

  // ====== Vues ======
  function showWelcome(){
    $("#welcome-screen")?.classList.remove("hidden");
    $("#quiz-screen")?.classList.add("hidden");
    $("#annotation-screen")?.classList.add("hidden");
  }
  function showQuizGate(force=false){
    const must = force || getLS(LS_KEYS.PASSED) !== "true";
    if (must) {
      $("#annotation-screen")?.classList.add("hidden");
      const host = createQuizModal(); // crée modal + #quiz-container
      host.innerHTML = "";            // reset
      buildQuiz();                    // rend dans #quiz-container
    } else {
      showAnnotation();
    }
  }
  function showAnnotation(){
    const ok = getLS(LS_KEYS.PASSED) === "true";
    if (!ok) { showQuizGate(true); return; }
    destroyQuizModal(); // sécurité
    $("#welcome-screen")?.classList.add("hidden");
    $("#quiz-screen")?.classList.add("hidden");
    $("#annotation-screen")?.classList.remove("hidden");
  }

  function buildQuiz(){
    const container = document.getElementById("quiz-container");
    if (!container) return;
    container.innerHTML = "";
    answers = [];

    const lang = (window.currentLanguage || $("#language-select")?.value || "fr").toLowerCase();
    const pool = codebook.filter(x => (x.lang||"").toLowerCase() === lang);
    const src  = pool.length >= NUM_QUESTIONS ? pool : codebook;
    quizItems  = shuffle(src).slice(0, NUM_QUESTIONS);

    renderQuiz(container);
  }

  // ====== Data ======
  async function loadCodebook(){
    try {
      const res = await fetch(PATH_CODEBOOK, { cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      if (!Array.isArray(data) || !data.length) throw new Error("Empty codebook");
      codebook = data;
      console.log("[quiz_gate] codebook OK:", PATH_CODEBOOK, "count=", data.length);
    } catch (e) {
      console.error("[quiz_gate] Codebook load failed:", e);
      codebook = []; // vide pour signaler le problème
    }
  }

  // ====== Init ======
  async function init(){
    saveLS(LS_KEYS.VERSION, QUIZ_VERSION);

    // Garde-fou global sur boutons de démarrage potentiels
    document.addEventListener("click", (e) => {
      const el = (e.target instanceof Element)
        ? e.target.closest("#start-annotation, #btn-start-annotation, [data-role='start-annotation'], [data-action='start-annotation']")
        : null;
      if (!el) return;
      if (getLS(LS_KEYS.PASSED) !== "true") {
        e.preventDefault(); e.stopPropagation();
        showQuizGate(true);
      } else {
        showAnnotation();
      }
    });

    await loadCodebook();

    // Crée le conteneur modal au besoin et force le quiz si non validé
    const passed = getLS(LS_KEYS.PASSED) === "true";
    // Ne PAS ouvrir le quiz automatiquement
    // Il sera déclenché par le clic sur "Commencer l'annotation" via le guard
    if (passed) {
      // Si déjà passé, laisser app.js gérer l'affichage
      if (document.querySelector("#welcome-screen")) showWelcome();
      else showAnnotation();
    }
    // Si pas passé, ne rien faire - attendre le clic sur Start
  }

  window.quizGate = { 
    init,
    resetQuiz: () => {
      clearQuizState();
      showQuizGate(true);
    }
  };

  document.addEventListener("DOMContentLoaded", init);
})();
