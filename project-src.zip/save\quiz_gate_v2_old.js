﻿// quiz_gate.js — Codebook Quiz Gate (v2)
// Bloque startAnnotation() tant que le quiz basé codebook n'est pas réussi.
// Stockage: quiz_passed_v1="1", quiz_failed_count_v1=compteur.
// Dépendances: data/codebook_v1.json + window.startAnnotation() existant.

(function () {
  // ---- Config ----
  const NUM_QUESTIONS = 4;     // 4 à 6 possible
  const TOL = 1;               // tolérance ±1
  const PASS_SCORE = 3;        // réussir ≥ 3/4
  const MAX_ATTEMPTS = 6;
  const LS_KEY_PASS  = "quiz_passed_v1";
  const LS_KEY_FAILS = "quiz_failed_count_v1";

  // ---- I18N minimal (auto) ----
  const I18N = {
    en: {
      title: "Practice on real mini-texts",
      intro: "Enter Fc (0–5) and Fi (0–5) for each short text. Think relative to the telos. Tolerance ±1.",
      tip: "Hint: Negative words can justify action (Fc↑) instead of blocking it (Fi). Obstacles must impede the telos.",
      head_stem: "Mini-text",
      head_telos: "Telos (frame)",
      lbl_fc: "Fc (0–5)",
      lbl_fi: "Fi (0–5)",
      rationale: "Why:",
      btn_submit: "Validate",
      btn_retry: "Try again",
      btn_close: "Close",
      summaryTitle: "Training summary",
      summaryMsgMedium: (s,n)=>`Score ${s}/${n}. Solid. You can either redo a short practice or start annotating.`,
      summaryMsgHigh:   (s,n)=>`Score ${s}/${n}. Excellent. You can start annotating.`,
      btnGoAnnot: "Start annotating",
      btnRedo: "Redo practice",
      need_all: "Please fill Fc and Fi for all items.",
      score_ok: (s,n)=>`Passed ${s}/${n}. You can start annotating.`,
      score_ko: (s,n)=>`Score ${s}/${n}. Need at least ${PASS_SCORE}/${n}.`,
      blocked: "Maximum attempts reached. Please re-read the welcome instructions."
    },
    fr: {
      title: "Entraînement sur de vrais mini-textes",
      intro: "Saisis Fc (0–5) et Fi (0–5) pour chaque court extrait. Toujours relatif au telos. Tolérance ±1.",
      tip: "Astuce : La négativité peut justifier l’action (Fc↑) plutôt que la freiner (Fi). Un obstacle freine réellement le telos.",
      head_stem: "Mini-texte",
      head_telos: "Telos (cadre)",
      lbl_fc: "Fc (0–5)",
      lbl_fi: "Fi (0–5)",
      rationale: "Pourquoi :",
      btn_submit: "Valider",
      btn_retry: "Réessayer",
      btn_close: "Fermer",
      summaryTitle: "Bilan de l’entraînement",
      summaryMsgMedium: (s,n)=>`Score ${s}/${n}. Solide. Vous pouvez refaire un court entraînement ou commencer l’annotation.`,
      summaryMsgHigh:   (s,n)=>`Score ${s}/${n}. Excellent. Vous pouvez commencer l’annotation.`,
      btnGoAnnot: "Passer à l’annotation",
      btnRedo: "Refaire l’entraînement",
      need_all: "Merci de renseigner Fc et Fi pour tous les items.",
      score_ok: (s,n)=>`Réussi ${s}/${n}. Vous pouvez démarrer l’annotation.`,
      score_ko: (s,n)=>`Score ${s}/${n}. Il faut au moins ${PASS_SCORE}/${n}.`,
      blocked: "Nombre de tentatives maximum atteint. Merci de relire les consignes d’accueil."
    },
    es: {
      title: "Práctica con mini-textos reales",
      intro: "Indica Fc (0–5) y Fi (0–5) para cada texto. Siempre relativo al telos. Tolerancia ±1.",
      tip: "Pista: La negatividad puede justificar la acción (Fc↑) en vez de frenarla (Fi). Un obstáculo impide el telos.",
      head_stem: "Mini-texto",
      head_telos: "Telos (marco)",
      lbl_fc: "Fc (0–5)",
      lbl_fi: "Fi (0–5)",
      rationale: "Por qué:",
      btn_submit: "Enviar",
      btn_retry: "Reintentar",
      btn_close: "Cerrar",
      summaryTitle: "Resumen del entrenamiento",
      summaryMsgMedium: (s,n)=>`Puntuación ${s}/${n}. Sólido. Puedes repetir una práctica corta o empezar a anotar.`,
      summaryMsgHigh:   (s,n)=>`Puntuación ${s}/${n}. Excelente. Puedes empezar a anotar.`,
      btnGoAnnot: "Empezar anotación",
      btnRedo: "Repetir entrenamiento",
      need_all: "Completa Fc y Fi en todos los ítems.",
      score_ok: (s,n)=>`Aprobado ${s}/${n}. Ya puedes anotar.`,
      score_ko: (s,n)=>`Puntuación ${s}/${n}. Se requiere al menos ${PASS_SCORE}/${n}.`,
      blocked: "Has alcanzado el máximo de intentos. Relee las instrucciones de inicio."
    },
    zh: {
      title: "基于真实迷你文本的练习",
      intro: "为每段短文本填写 Fc(0–5) 与 Fi(0–5)。始终相对 telos。容差 ±1。",
      tip: "提示：负向词可能在论证行动的必要性（Fc↑），而非构成阻碍（Fi）。真正的障碍会阻碍 telos。",
      head_stem: "迷你文本",
      head_telos: "Telos（框架）",
      lbl_fc: "Fc (0–5)",
      lbl_fi: "Fi (0–5)",
      rationale: "原因：",
      btn_submit: "提交",
      btn_retry: "重试",
      btn_close: "关闭",
      summaryTitle: "训练总结",
      summaryMsgMedium: (s,n)=>`得分 ${s}/${n}。不错。你可以再练一次或直接开始标注。`,
      summaryMsgHigh:   (s,n)=>`得分 ${s}/${n}。非常好。你可以开始标注。`,
      btnGoAnnot: "开始标注",
      btnRedo: "重新训练",
      need_all: "请为所有项目填写 Fc 和 Fi。",
      score_ok: (s,n)=>`通过 ${s}/${n}。可以开始标注。`,
      score_ko: (s,n)=>`得分 ${s}/${n}。至少需要 ${PASS_SCORE}/${n}。`,
      blocked: "已达最大尝试次数。请返回欢迎页阅读说明。"
    }
  };

  function getLang() {
    try {
      if (window.currentLanguage) return normalize(window.currentLanguage);
      const sel = document.getElementById('language-select');
      if (sel && sel.value) return normalize(sel.value);
    } catch {}
    return 'en';
  }
  function normalize(x){ x=(x||'en').toLowerCase(); return ({fr:'fr',es:'es',zh:'zh'})[x]||'en'; }
  function P(){ const L=getLang(); return I18N[L]||I18N.en; }

  // ---- Codebook loader ----
  async function loadCodebook() {
    const res = await fetch('data/codebook_v1.json', {cache:'no-store'});
    if (!res.ok) throw new Error('codebook load failed');
    const all = await res.json();
    const L = getLang().toUpperCase(); // codebook lang est en FR/EN/ES/ZH
    const pool = all.filter(it => (it.lang||'').toUpperCase() === L);
    if (pool.length === 0) throw new Error('no items for language');
    return shuffle(pool).slice(0, NUM_QUESTIONS);
  }
  function shuffle(a){ for(let i=a.length-1;i>0;i--){const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]];} return a; }

  // ---- DOM modal (styles + markup) ----
  function ensureModalInjected() {
    if (document.getElementById('quiz-gate-backdrop')) return;
    const css = `
      #quiz-gate-backdrop{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.6);z-index:9998}
      #quiz-gate-modal{width:min(860px,94vw);max-height:86vh;overflow:auto;background:#fff;color:#222;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.35);padding:22px;z-index:9999;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
      #quiz-gate-modal h2{color:#667eea;margin:0 0 8px}
      .quiz-intro{margin:4px 0 10px;color:#444}
      .quiz-tip{background:#f8f9fa;border-left:4px solid #667eea;padding:10px;border-radius:8px;margin:8px 0 14px;font-size:14px;color:#333}
      .q-item{border:2px solid #eee;border-radius:12px;padding:12px;margin:10px 0}
      .q-head{display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px;color:#555;margin-bottom:8px}
      .q-stem{font-weight:600;color:#222}
      .q-telos{opacity:.9}
      .q-inputs{display:flex;gap:10px;align-items:center;margin-top:6px}
      .q-inputs input{width:60px;padding:6px 8px;border:1px solid #ccc;border-radius:8px}
      .q-feedback{font-size:12px;color:#555;margin-top:6px}
      .quiz-actions{display:flex;gap:12px;justify-content:flex-end;margin-top:14px}
      .btn{padding:10px 18px;border-radius:999px;border:2px solid transparent;cursor:pointer;font-weight:600}
      .btn-primary{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
      .btn-secondary{background:#fff;color:#667eea;border-color:#667eea}
      .btn:disabled{opacity:.5;cursor:not-allowed}
      .quiz-note{font-size:12px;color:#555;margin-top:8px}
      .ok{color:#0b8e38;font-weight:700}
      .ko{color:#b71c1c;font-weight:700}
    `;
    const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);

    const bd = document.createElement('div'); bd.id = 'quiz-gate-backdrop';
    const md = document.createElement('div'); md.id = 'quiz-gate-modal';
    bd.appendChild(md); document.body.appendChild(bd);
  }

  async function openQuiz() {
    ensureModalInjected();
    const pack = P();
    const bd = document.getElementById('quiz-gate-backdrop');
    const md = document.getElementById('quiz-gate-modal');
    md.innerHTML = `
      <h2>${pack.title}</h2>
      <p class="quiz-intro">${pack.intro}</p>
      <div class="quiz-tip">ℹ️ ${pack.tip}</div>
      <div id="quiz-items"></div>
      <div class="quiz-actions">
        <button type="button" class="btn btn-secondary" id="quiz-close">${pack.btn_close}</button>
        <button type="button" class="btn btn-primary" id="quiz-submit">${pack.btn_submit}</button>
      </div>
      <div class="quiz-note" id="quiz-note"></div>
    `;
    bd.style.display = 'flex';

    let items;
    try {
      items = await loadCodebook();
    } catch(e) {
      // Fallback clair si codebook indisponible
      document.getElementById('quiz-note').textContent =
        (getLang()==='fr')
          ? "Codebook indisponible pour cette langue. Merci de réessayer plus tard."
          : "Codebook unavailable for this language. Please try again later.";
      document.getElementById('quiz-submit').disabled = true;
      return;
    }

    // Rendu des items
    const host = document.getElementById('quiz-items');
    items.forEach((it, idx) => {
      const html = `
        <div class="q-item" data-idx="${idx}">
          <div class="q-head">
            <div><span style="color:#003366;font-weight:600;font-size:16px;">${pack.head_stem}:</span> <span class="q-stem">${escapeHTML(it.stem||'')}</span></div>
            <div><span style="color:#003366;font-weight:600;font-size:16px;">${pack.head_telos}:</span> <span class="q-telos" style="color:#dc3545;font-weight:600;font-size:17px;">${escapeHTML(it.telos||'')}</span></div>
          </div>
          <div class="q-inputs">
            <label>${pack.lbl_fc} <input type="number" min="0" max="5" step="1" class="in-fc"></label>
            <label>${pack.lbl_fi} <input type="number" min="0" max="5" step="1" class="in-fi"></label>
          </div>
          <div class="q-feedback" id="fb-${idx}"></div>
        </div>
      `;
      const wrap = document.createElement('div'); wrap.innerHTML = html; host.appendChild(wrap.firstElementChild);
    });

    md.querySelector('#quiz-close').addEventListener('click', closeQuiz);
    md.querySelector('#quiz-submit').addEventListener('click', () => submitQuiz(items));
  }

  function closeQuiz() {
    const bd = document.getElementById('quiz-gate-backdrop');
    if (bd) bd.style.display = 'none';
  }
  function showQuizSummary(score, n) {
    const pack = P(); // i18n pack

    const md = document.getElementById('quiz-gate-modal');
    if (!md) return;

    const isPerfect = (score === n);

    md.innerHTML = `
      <h2>${pack.summaryTitle}</h2>
      <p>${isPerfect ? pack.summaryMsgHigh(score, n) : pack.summaryMsgMedium(score, n)}</p>
      <div class="quiz-actions">
        <button type="button" class="btn btn-secondary" id="sum-redo">${pack.btnRedo}</button>
        <button type="button" class="btn btn-primary" id="sum-go">${pack.btnGoAnnot}</button>
      </div>
    `;

    // Si score parfait, masquer le bouton “Refaire” (optionnel)
    if (isPerfect) {
      const redoBtn = document.getElementById('sum-redo');
      if (redoBtn) redoBtn.style.display = 'none';
    }

    // Refaire l’entraînement: relancer un nouveau tirage d’items
    const btnRedo = document.getElementById('sum-redo');
    if (btnRedo) {
      btnRedo.onclick = () => {
        openQuiz(); // recharge le quiz avec de nouveaux stems du codebook
      };
    }

    // Démarrer l’annotation: pose le drapeau de passage et sort
    const btnGo = document.getElementById('sum-go');
    if (btnGo) {
      btnGo.onclick = () => {
        localStorage.setItem(LS_KEY_PASS, "1");
        closeQuiz();
        if (typeof window.__startAnnotation_original === 'function') {
          window.__startAnnotation_original();
        }
      };
    }
  }
  function submitQuiz(items) {
    const pack = P();
    const n = items.length;
    let score = 0;
    let allFilled = true;

    items.forEach((it, idx) => {
      const box = document.querySelector(`.q-item[data-idx="${idx}"]`);
      const fcVal = parseInt((box.querySelector('.in-fc')||{}).value, 10);
      const fiVal = parseInt((box.querySelector('.in-fi')||{}).value, 10);

      if (Number.isNaN(fcVal) || Number.isNaN(fiVal)) allFilled = false;

      const okFc = Math.abs(fcVal - it.Fc_target) <= TOL;
      const okFi = Math.abs(fiVal - it.Fi_target) <= TOL;

      const fb = box.querySelector(`#fb-${idx}`);
      if (!Number.isNaN(fcVal) && !Number.isNaN(fiVal)) {
        if (okFc && okFi) {
          fb.innerHTML = `<span class="ok">✔</span> ${escapeHTML(items[idx].rationale || '')}`;
          score += 1;
        } else {
          fb.innerHTML = `<span class="ko">✖</span> ${escapeHTML(items[idx].rationale || '')}`;
        }
      } else {
        fb.textContent = '';
      }
    });

    const note = document.getElementById('quiz-note');
    if (!allFilled) {
      note.textContent = pack.need_all;
      return;
    }

    if (score >= PASS_SCORE) {
      // Ne pas valider tout de suite
      // → afficher l’écran bilan avec choix “Refaire” ou “Passer à l’annotation”
      showQuizSummary(score, n);
    } else {
      const fails = Math.min(
        (parseInt(localStorage.getItem(LS_KEY_FAILS) || '0', 10) + 1),
        MAX_ATTEMPTS
      );
      localStorage.setItem(LS_KEY_FAILS, String(fails));
      if (fails >= MAX_ATTEMPTS) {
        note.textContent = pack.blocked;
        document.getElementById('quiz-submit').disabled = true;
      } else {
        note.textContent = pack.score_ko(score, n);
        const submitBtn = document.getElementById('quiz-submit');
        submitBtn.textContent = P().btn_retry;
      }
    }
  }

  function escapeHTML(s){ return String(s||'').replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m])); }

  // ---- Hook startAnnotation() (identique au v1) ----
  function hookStartAnnotation() {
    if (window.__startAnnotation_original) return;

    if (typeof window.startAnnotation !== 'function') {
      setTimeout(hookStartAnnotation, 100);
      return;
    }
    window.__startAnnotation_original = window.startAnnotation;

    window.startAnnotation = function () {
      try {
        const passed = localStorage.getItem(LS_KEY_PASS) === "1";
        const fails  = parseInt(localStorage.getItem(LS_KEY_FAILS) || '0', 10);

        if (passed) return window.__startAnnotation_original();
        if (fails >= MAX_ATTEMPTS) { alert(P().blocked); return; }

        openQuiz();
      } catch (e) {
        console.warn('quiz_gate fallback:', e);
        return window.__startAnnotation_original();
      }
    };
  }

  document.addEventListener('DOMContentLoaded', hookStartAnnotation);
})();
